package com.cj.ui;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cj.util.SmartProperties;

/**
 * 
 * @author SeokheeLee 
 * Date : 2017-06-01
 * Subject : CJ Mall 운영 
 * Name : test
 * Scenario : 
 * Assertion : 
 * Update : 
 *
 */

public class test0601 {
	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	
	private String userId = null;
	private String passwd = null;
	private String browser = null;
	private long waitTime = 50;
	private String testpasswd = null;
	private String word_tc014_01 = null;
	private String word_tc051_01 = null;
	private String word_tc051_02 = null;

	@Before
	public void setUp() throws Exception {
		
		SmartProperties sp = SmartProperties.getInstance();
		userId = sp.getProperty("ID");
		passwd = sp.getProperty("PWD");
		waitTime = Long.parseLong(sp.getProperty("WaitTime"));
		browser = sp.getProperty("Browser");
		word_tc014_01 = sp.getProperty("Word_TC014_01");
		word_tc051_01 = sp.getProperty("Word_TC051_01");
		word_tc051_02 = sp.getProperty("Word_TC051_02");
		testpasswd = sp.getProperty("TESTPWD");

		if (browser.equalsIgnoreCase("firefox")){
			driver = new FirefoxDriver();
			}
			
		else {driver = new ChromeDriver();
		}

		sp.list(System.out);

		System.out.println("userId 	= " + userId);
		System.out.println("passwd 	= " + passwd);
		System.out.println("waitTime=" + waitTime);
		System.out.println("word_tc014_01 = " + word_tc014_01);
		System.out.println("word_tc051_01 = " + word_tc051_01);
		System.out.println("word_tc051_02 = " + word_tc051_02);
		System.out.println("testpasswd=" + testpasswd);

		baseUrl = "http://www.cjmall.com/";
		driver.manage().window().maximize();
	}	

	@Test
	public void test0601() throws Exception {
		try {
			WebDriverWait wait = null;

			driver.manage().window().maximize();
			
			// 메인 페이지 요청
			driver.get("http://display.cjmall.com/p/homeTab/main?hmtabMenuId=000002&rPIC=Oclock");
			System.out.println("메인 페이지 요청");

			Thread.sleep(5000);
			
			//로그인 클릭
		    driver.findElement(By.xpath(".//*[@id='header']/div[1]/div[5]/ul/li[1]/a")).click();
			System.out.println("로그인 클릭");
			
			Thread.sleep(5000);
		
			driver.findElement(By.xpath(".//*[@id='id_input']")).click();
			driver.findElement(By.xpath(".//*[@id='id_input']")).clear();
			driver.findElement(By.xpath(".//*[@id='id_input']")).sendKeys(userId);
			driver.findElement(By.xpath(".//*[@id='password_input']")).clear();
			driver.findElement(By.xpath(".//*[@id='password_input']")).sendKeys(passwd);
			driver.findElement(By.xpath(".//*[@id='loginSubmit']")).click();

			Thread.sleep(5000);
			
		    driver.findElement(By.xpath(".//*[@id='submitFrm']/fieldset/div[1]/div[2]/dl")).click();
			System.out.println("검색창 클릭");
			Thread.sleep(5000);
			driver.findElement(By.xpath(".//*[@id='srh_keyword']")).sendKeys("가습기");
			Thread.sleep(5000);
			driver.findElement(By.xpath(".//*[@id='submitFrm']/fieldset/div[1]/div[3]/button")).click();
			Thread.sleep(5000);
			
			driver.findElement(By.xpath(".//*[@id='lst_cate_result']/li[1]/a/span[1]")).click();
			System.out.println("임의의 상품 선택");
			Thread.sleep(5000);
			
			driver.findElement(By.xpath(".//*[@id='content']/div[2]/div[1]/div[2]/div[2]/div[3]/a")).click();
			System.out.println("바로구매 버튼 선택");
			Thread.sleep(5000);
			
			driver.findElement(By.xpath(".//*[@id='_btn_change_payment']")).click();
			System.out.println("결재수단 변경 버튼 선택");
			
			driver.findElement(By.xpath(".//*[@id='chkbx1']")).click();
			System.out.println("신용카드 버튼 선택");
			
			driver.findElement(By.xpath(".//*[@id='_select_card_lst']")).click();
			System.out.println("신용카드 리스트 선택");
			
			driver.findElement(By.xpath(".//*[@id='_select_card_lst']/option[5]")).click();
			System.out.println("삼성카드 리스트 선택");
			
			driver.findElement(By.xpath(".//*[@id='order_payment']/fieldset/div[4]/span/label/span")).click();
			System.out.println("동의함 선택");

			driver.findElement(By.xpath(".//*[@id='_buy']")).click();
			System.out.println("결제하기 선택");
			
			
			Thread.sleep(5000);
			
			
			
			
						
			// "TV쇼핑 > 주간편성표" Text 확인
		/*	if("TV쇼핑 > 생방송/편성표보기".equals(driver.findElement(By.xpath(".//*[@id='locationEtcDiv']")).getText())){
				System.out.println("[TC_251] success");
				assertTrue(true);
				return;
			} else {
				System.out.println("[TC_251] failure : 'TV쇼핑 > 주간편성표 Text 불일치'");
				assertTrue(false);
			}*/
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("[TC_251] failure");
			assertTrue(false);
		}
	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	public boolean existElement(WebDriver wd, By by, String meaning) {
		WebDriverWait wait = new WebDriverWait(wd, 2);
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(by));

		} catch (TimeoutException e) {

			System.out.println("[" + meaning + "] WebElement does not Exist. time out ");
			return false;
		}
		System.out.println("[" + meaning + "] WebElement Exist.");
		return true;
	}

}
