package com.cj.pc;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;
import com.cj.util.SmartProperties;

public class P_062 {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	private String ID_1 = null;
	private String ID_2 = null;
	private String ID_3 = null;
	private String ID_4 = null;
	private String ID_5 = null;
	private String PW_1 = null;
	private String PW_2 = null;
	private String PW_3 = null;
	private String PW_4 = null;
	private String PW_5 = null;
	private String P_URL = null;
	private String M_URL = null;
	private String NAME = null;
	private String BIRTH = null;
	private long waitTime = 50;

	 /**
	   * 
	   * @author 조성주
	   * Date : 2017-06-13
	   * Subject : CJ Mall 운영 
	   * Name : TC_62
	   * Scenario : 임의의 상품 무통장 입금 으로 결제하기
	   * Assertion : 결제완료 Text 체크
	   *
	   */ 
	@Before
	public void setUp() throws Exception {
		driver = new ChromeDriver();
		baseUrl = "http://display.cjmall.com/p/homeTab/main?hmtabMenuId=000002&rPIC=Oclock&pic=GNBA|bi";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();

		SmartProperties sp = SmartProperties.getInstance();
		ID_1 = sp.getProperty("ID_1");
		ID_2 = sp.getProperty("ID_2");
		ID_3 = sp.getProperty("ID_3");
		ID_4 = sp.getProperty("ID_4");
		ID_5 = sp.getProperty("ID_5");
		PW_1 = sp.getProperty("PW_1");
		PW_2 = sp.getProperty("PW_2");
		PW_3 = sp.getProperty("PW_3");
		PW_4 = sp.getProperty("PW_4");
		PW_5 = sp.getProperty("PW_5");
		P_URL = sp.getProperty("P_URL");
		M_URL = sp.getProperty("M_URL");
		NAME = sp.getProperty("NAME");
		BIRTH = sp.getProperty("BIRTH");
		// sp.list(System.out);

		// System.out.println("ID_1 = " + ID_1);

	}

	@Test
	public void testTc001() throws Exception {
		// 로그인 
		driver.get(baseUrl + "/p/homeTab/main?hmtabMenuId=000002&rPIC=Oclock");
		driver.findElement(By.cssSelector("span.ico")).click();
		driver.findElement(By.xpath("//*[@id='id_input']")).clear();
	    driver.findElement(By.xpath("//*[@id='id_input']")).sendKeys(ID_1);
	    driver.findElement(By.xpath(".//*[@id='password_input']")).clear();
	    driver.findElement(By.xpath(".//*[@id='password_input']")).sendKeys(PW_1);
	    driver.findElement(By.xpath(".//*[@id='loginSubmit']")).click();
		driver.findElement(By.cssSelector("dd")).click();
		Thread.sleep(3000);
		// 상품진입
	    driver.findElement(By.id("srh_keyword")).clear();
	    driver.findElement(By.id("srh_keyword")).sendKeys("가습기");
	    driver.findElement(By.cssSelector("button._search")).click();
	    driver.findElement(By.cssSelector("a.link_product > span.img")).click();
	    driver.findElement(By.linkText("바로구매")).click();
	    Thread.sleep(3000);
	    driver.findElement(By.xpath(".//*[@id='order_payment']/fieldset/div[4]/span/label")).click();
	    driver.findElement(By.xpath(".//*[@id='_buy']")).click();
		Thread.sleep(3000);
		// text check
		if ("주문완료".equals(driver.findElement(By.xpath(".//*[@id='content']/div/h2[1]")).getText())) {
			System.out.println("TC_62 PASS");
			assertTrue(true);
			return;
		} else {
			System.out.println("TC_62 FAIL");
			assertTrue(false);
		}

	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	public boolean existElement(WebDriver wd, By by, String meaning) {
		WebDriverWait wait = new WebDriverWait(wd, 2);
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(by));

		} catch (TimeoutException e) {

			System.out.println("[" + meaning + "] WebElement does not Exist. time out ");
			return false;
		}
		System.out.println("[" + meaning + "] WebElement Exist.");
		return true;
	}
	
	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
